package function;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int empId = Integer.parseInt(request.getParameter("emp_id"));
        String designation = request.getParameter("designation");
        String department = request.getParameter("department");

        
        if (empId == 100100 && "admin".equals(designation) && "admin".equals(department)) {
            HttpSession session = request.getSession();
            session.setAttribute("emp_id", empId);
            response.sendRedirect("admin.jsp");
            return;
        }
        
        
        Connection conn = null;
PreparedStatement pstmt = null;
ResultSet rs = null;

try {
    // Load the JDBC driver
    Class.forName("com.mysql.cj.jdbc.Driver");

    // Connect to the database
    String dbURL = "jdbc:mysql://localhost:3306/booking";
    String dbUser = "root";
    String dbPass = "root";
    conn = DriverManager.getConnection(dbURL, dbUser, dbPass);

    // Prepare the SQL statement
    String sql = "SELECT * FROM emp_details WHERE emp_id = ? AND designation = ? AND department = ?";
    pstmt = conn.prepareStatement(sql);
    pstmt.setInt(1, empId);
    pstmt.setString(2, designation);
    pstmt.setString(3, department);

    // Execute the query
    rs = pstmt.executeQuery();

    // Check if the emp_id, designation, and department match
    if (rs.next()) {
        // Successful login, set the session attribute and redirect to dashboard
        HttpSession session = request.getSession();
        session.setAttribute("emp_id", empId);
        response.sendRedirect("dashboard.jsp");
    } else {
        // Login failed, redirect to login page with an error message
    	 request.setAttribute("errorMessage", "Invalid credentials");
         request.getRequestDispatcher("emp_login.jsp").forward(request, response);
    }
} catch (Exception e) {
    e.printStackTrace();
    request.setAttribute("errorMessage", "An error occurred. Please try again.");
    request.getRequestDispatcher("emp_login.jsp").forward(request, response);

} finally {
    // Close the resources
    try {
        if (rs != null) rs.close();
        if (pstmt != null) pstmt.close();
        if (conn != null) conn.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
    }
}
