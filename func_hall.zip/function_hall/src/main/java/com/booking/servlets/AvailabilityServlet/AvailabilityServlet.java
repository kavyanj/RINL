package com.booking.servlets.AvailabilityServlet;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Availability")
public class AvailabilityServlet extends HttpServlet {

    static class DatabaseConnection {
        private static final String JDBC_URL = "jdbc:mysql://localhost:3306/booking";
        private static final String USERNAME = "root";
        private static final String PASSWORD = "root";

        public static Connection getConnection() throws SQLException {
            return DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String yearStr = request.getParameter("year");
        String monthStr = request.getParameter("month");

        int year = Integer.parseInt(yearStr);
        int month = Integer.parseInt(monthStr);

        StringBuilder jsonResponse = new StringBuilder();
        jsonResponse.append("[");

        String query = "SELECT date_booking, availability FROM finalbook WHERE YEAR(date_booking) = ? AND MONTH(date_booking) = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, year);
            pstmt.setInt(2, month);

            ResultSet rs = pstmt.executeQuery();

            boolean isFirst = true;
            while (rs.next()) {
                if (!isFirst) {
                    jsonResponse.append(",");
                } else {
                    isFirst = false;
                }

                String date = rs.getString("date_booking");
                int availability = rs.getInt("availability");

                jsonResponse.append("{");
                jsonResponse.append("\"date\":\"").append(date).append("\",");
                jsonResponse.append("\"availability\":").append(availability);
                jsonResponse.append("}");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        jsonResponse.append("]");

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(jsonResponse.toString());
        
        System.out.println(jsonResponse.toString());
    }
}