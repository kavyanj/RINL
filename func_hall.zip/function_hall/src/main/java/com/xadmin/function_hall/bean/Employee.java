package com.xadmin.function_hall.bean;

public class Employee {
	private int emp_id;
	private String designation;
	private String department;
    private String address;
    private String office_ph;
    private String cell_no;
    
    
	
    public Employee(int emp_id, String designation, String department, String address, String office_ph,
			String cell_no) {
		super();
		this.emp_id = emp_id;
		this.designation = designation;
		this.department = department;
		this.address = address;
		this.office_ph = office_ph;
		this.cell_no = cell_no;
	}
	
    public Employee(String designation, String department, String address, String office_ph, String cell_no) {
  		super();
  		this.designation = designation;
  		this.department = department;
  		this.address = address;
  		this.office_ph = office_ph;
  		this.cell_no = cell_no;
  	}
    
    public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getOffice_ph() {
		return office_ph;
	}
	public void setOffice_ph(String office_ph) {
		this.office_ph = office_ph;
	}
	public String getCell_no() {
		return cell_no;
	}
	public void setCell_no(String cell_no) {
		this.cell_no = cell_no;
	}
   
}