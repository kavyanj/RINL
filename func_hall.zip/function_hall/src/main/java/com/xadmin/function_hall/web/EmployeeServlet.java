package com.xadmin.function_hall.web;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.xadmin.function_hall.dao.EmployeeDao;
import com.xadmin.function_hall.bean.Employee;



@WebServlet({ "/list", "/new", "/insert", "/delete", "/edit", "/update" })
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeDao employeeDao;
	
	public void init() {
		employeeDao= new EmployeeDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertUser(request, response);
				break;
			case "/delete":
				deleteUser(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateUser(request, response);
				break;
			default:
				listUser(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Employee> listUser = employeeDao.selectAllUsers();
		request.setAttribute("listUser", listUser); 
		RequestDispatcher dispatcher = request.getRequestDispatcher("user_list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user_form.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
	        throws SQLException, ServletException, IOException {
	    String empIdStr = request.getParameter("emp_id");
	    if (empIdStr != null && !empIdStr.isEmpty()) {
	        int emp_id = Integer.parseInt(empIdStr);
	        Employee existingUser = employeeDao.selectUser(emp_id);
	        if (existingUser != null) {
	        request.setAttribute("emp", existingUser);
	        RequestDispatcher dispatcher = request.getRequestDispatcher("user_form.jsp");
	        dispatcher.forward(request, response);
	    } 
	        else {
                // Handle case where employee with given emp_id is not found
                response.sendRedirect("list");
            }
        }
	        else {
	        // Handle the case where emp_id is null or empty
	        response.sendRedirect("list");
	    }
	}
	

	private void insertUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int emp_id = Integer.parseInt(request.getParameter("emp_id"));
		String designation = request.getParameter("designation");
		String department = request.getParameter("department");
		String address = request.getParameter("address");
		String office_ph = request.getParameter("office_ph");
		String cell_no = request.getParameter("cell_no");
		
		Employee newUser = new Employee( emp_id,designation, department, address,office_ph,cell_no);
		employeeDao.insertUser(newUser);
		response.sendRedirect("list");
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ServletException {
		int emp_id = Integer.parseInt(request.getParameter("emp_id"));
		String designation = request.getParameter("designation");
		String department = request.getParameter("department");
		String address = request.getParameter("address");
		String office_ph = request.getParameter("office_ph");
		String cell_no = request.getParameter("cell_no");
		 
		Employee book = new Employee(emp_id,designation, department, address,office_ph,cell_no);
		  try {
	            employeeDao.updateUser(book);
	            response.sendRedirect("list"); // Redirect to list page after successful update
	        } catch (SQLException e) {
	            throw new ServletException("Error updating employee", e);
	        }
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("emp_id"));
		employeeDao.deleteUser(id);
		response.sendRedirect("list");

	}

}

