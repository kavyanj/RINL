package com.functionhall1;
import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String fullName = request.getParameter("full_name");
        String email = request.getParameter("email");
        String phoneNumber = request.getParameter("phone_number");
        String address = request.getParameter("address");
        String password = request.getParameter("password");

        String url = "jdbc:mysql://localhost:3306/booking";
        String dbUsername = "root";
        String dbPassword = "root";

        try {
            // Load JDBC driver
            Class.forName("com.mysql.jdbc.Driver");
            // Connect to the database
            Connection con = DriverManager.getConnection(url, dbUsername, dbPassword);
            // Create a SQL statement
            String sql = "INSERT INTO out_details(full_name, email, phone_number, address, password) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = con.prepareStatement(sql);
            // Set parameters
            statement.setString(1, fullName);
            statement.setString(2, email);
            statement.setString(3, phoneNumber);
            statement.setString(4, address);
            statement.setString(5, password);
            // Execute the statement
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                request.setAttribute("message", "Registration successful!");
            } else {
                request.setAttribute("message", "Failed to register. Please try again later.");
            }
            // Close the connection
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        // Forward the request to the registration form page
        RequestDispatcher dispatcher = request.getRequestDispatcher("registration.jsp");
        dispatcher.forward(request, response);
    }
}
