package com.servlet.book;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/book")
public class booking_servlet extends HttpServlet {

    private static final String INSERT_QUERY = "INSERT INTO booking_reg(category,date_booking,emp_id,name,designation,department,address,office_num,cell_num,occasion,relation,dd_num,dd_date,amount,ac_from,ac_to,remarks) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String CHECK_EMP_QUERY = "SELECT COUNT(*) FROM emp_details WHERE emp_id = ?";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String dateBooking = request.getParameter("date_booking"); // Get the date_booking parameter from the request
        response.setContentType("text/html"); // Set the content type to HTML
        PrintWriter out = response.getWriter(); // Get the PrintWriter to write the response
        try {
            fetchAndPresentAvailableSlotsAndHalls(dateBooking, out); // Call the method to fetch and present available slots and halls
        } catch (SQLException e) {
            e.printStackTrace();  // Print stack trace if there is an SQL exception
        }
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        
        String category = req.getParameter("category");
        String date_book = req.getParameter("date_booking");
        String emp_i= req.getParameter("emp_id");
        int empId = emp_i != null && !emp_i.isEmpty() ? Integer.parseInt(emp_i) : 0;
        
        if (!isEmployeeIdValid(empId)) {
            String errorMessage = "Invalid employee ID. Please check your employee ID and try again.";
            req.setAttribute("errorMessage", errorMessage);
            req.getRequestDispatcher("booking.jsp").forward(req, resp);
            return;
        }

        HttpSession s = req.getSession();
        s.setAttribute("emp_id", empId);
       
        String name = req.getParameter("name");
        String designation = req.getParameter("designation");
        String department = req.getParameter("department");
        String address = req.getParameter("address");
        String office_num = req.getParameter("office_num");
        String cell_num = req.getParameter("cell_num");
        String occasion = req.getParameter("occasion");
        String relation = req.getParameter("relation");
        String dd_nu = req.getParameter("dd_num");
        int dd_num = dd_nu != null && !dd_nu.isEmpty() ? Integer.parseInt(dd_nu) : 0;
        String dd_date = req.getParameter("dd_date");
        String amt = req.getParameter("amount");
        int amount = amt != null && !amt.isEmpty() ? Integer.parseInt(amt) : 0;
        String ac_from = req.getParameter("ac_from");
        String ac_to = req.getParameter("ac_to");
        String remarks = req.getParameter("remarks");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection("jdbc:mysql:///booking", "root", "root")) {
            	if (isEmployeeIdValid(empId)) {
                try (PreparedStatement ps = con.prepareStatement(INSERT_QUERY)) {
                    ps.setString(1, category);
                    ps.setString(2, date_book);
                    ps.setInt(3, empId);
                    ps.setString(4, name);
                    ps.setString(5, designation);
                    ps.setString(6, department);
                    ps.setString(7, address);
                    ps.setString(8, office_num);
                    ps.setString(9, cell_num);
                    ps.setString(10, occasion);
                    ps.setString(11, relation);
                    ps.setInt(12, dd_num);
                    ps.setString(13, dd_date);
                    ps.setInt(14, amount);
                    ps.setString(15, ac_from);
                    ps.setString(16, ac_to);
                    ps.setString(17, remarks);

                    int count = ps.executeUpdate();
                    if (count == 0) {
                        out.println("Record not stored into database");
                    } else {
                        // Fetch and present available slots
                        fetchAndPresentAvailableSlotsAndHalls(date_book, out);
                    }
                }
            }
            	else {
            		String errorMessage = "Invalid employee ID. Please check your employee ID and try again.";
                    req.setAttribute("errorMessage", errorMessage);
                    req.getRequestDispatcher("booking.jsp").forward(req, resp);
                    return;
                } }
        } catch (Exception e) {
            out.println(e.getMessage());
            e.printStackTrace(out);
        }

        out.close();
    }
    
    private boolean isEmployeeIdValid(int empId) {
        boolean isValid = false;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection("jdbc:mysql:///booking", "root", "root")) {
                String query = "SELECT * FROM emp_details WHERE emp_id = ?";
                try (PreparedStatement ps = con.prepareStatement(query)) {
                    ps.setInt(1, empId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            isValid = true; // Employee ID exists in emp_details table
                        }
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return isValid;
    }
    
    private void fetchAndPresentAvailableSlotsAndHalls(String dateBooking, PrintWriter out) throws SQLException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql:///booking", "root", "root");

            ps = con.prepareStatement("SELECT slot, halls_available FROM finalbook WHERE date_booking = ? AND availability = 1");
            ps.setString(1, dateBooking);
            rs = ps.executeQuery();

            // Generate HTML to present available slots and halls
            out.println("<html>");
            out.println("<head>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; background-color: #f4f4f9; color: #333; }");
            out.println("h2 { color: #0056b3; }");
            out.println("form { margin-top: 20px; }");
            out.println(".slot-hall { padding: 10px; border: 1px solid #ccc; margin-bottom: 10px; background-color: #fff; border-radius: 5px; }");
            out.println("input[type='checkbox'] { margin-right: 10px; }");
            out.println("input[type='submit'] { background-color: #0056b3; color: #fff; padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; }");
            out.println("input[type='submit']:hover { background-color: #004494; }");
            
            out.println("</style>");
           
            out.println("</head>");
            out.println("<body>");
            out.println("<h2>Available Slots and Halls on " + dateBooking + "</h2>");
            out.println("<form id='bookingForm' action='updateAvailability.jsp' method='post' onsubmit='resetForm()'>"); // Form to submit selected slots and halls
            if (rs != null && rs.next()) { // Check if ResultSet is not null and contains results
                do {
                    String slot = rs.getString("slot");
                    String hall = rs.getString("halls_available");
                    out.println("<div class='slot-hall'>");
                    out.println("<input type='checkbox' name='selectedSlotsAndHalls' value='" + slot + " " + hall + "'>" + slot + " - " + hall);
                    out.println("</div>");
                } while (rs.next());
                out.println("<input type='hidden' name='date_booking' value='" + dateBooking + "'>");
                out.println("<input type='submit' value='Book Selected Slots and Halls'>"); // Submit button to update availability
                out.println("</form>");
            } else {
                out.println("<p>No available slots and halls found for the selected date.</p>");
            }
            out.println("<form action='' method='get'>"); // Form to select a different date
            out.println("<label for='newDate'>Select a new date:</label>");
            out.println("<input type='date' id='newDate' name='date_booking' required>");
            out.println("<input type='submit' value='Book for Another Date'>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
        } catch (Exception e) {
            out.println(e.getMessage());
            e.printStackTrace(out);
        } finally {
            // Close resources
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        }
    }

   
}