package com.servlet.delete;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jakarta.servlet.annotation.WebServlet;


@WebServlet("/delete")
public class delete_servlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form data
        String date_booking = request.getParameter("date_booking");
        String slot = request.getParameter("slot");
        String halls_available = request.getParameter("halls_available");

        // Database connection
        String dbURL = "jdbc:mysql://localhost:3306/booking";
        String dbUser = "root";
        String dbPassword = "root";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Load the MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

            // SQL query to delete the booking
            String sql = "DELETE FROM finalbook WHERE date_booking = ? AND slot = ? AND halls_available= ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, date_booking);
            preparedStatement.setString(2, slot);
            preparedStatement.setString(3, halls_available);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                // Booking deleted, set the availability again to 1
                String updateSql = "UPDATE fianlbook SET availability = 1 WHERE date_booking = ? AND slot = ? AND halls_available = ?";
                preparedStatement = connection.prepareStatement(updateSql);
                preparedStatement.setString(1, date_booking);
                preparedStatement.setString(2, slot);
                preparedStatement.setString(3, halls_available);
                preparedStatement.executeUpdate();

                // Redirect to success page or display a success message
                System.out.println("Deletion successful");
                response.sendRedirect("deletion.jsp");
            } else {
                // Booking not found, display an error message
                response.sendRedirect("Error.jsp");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Handle errors
            response.sendRedirect("Error.jsp");
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}