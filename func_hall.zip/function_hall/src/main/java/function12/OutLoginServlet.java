
package function12;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/OutLoginServlet")
public class OutLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String full_name= request.getParameter("full_name");
        String password = request.getParameter("password");
        

        Connection conn = null;
PreparedStatement pstmt = null;
ResultSet rs = null;

try {
    // Load the JDBC driver
    Class.forName("com.mysql.cj.jdbc.Driver");

    // Connect to the database
    String dbURL = "jdbc:mysql://localhost:3306/booking";
    String dbUser = "root";
    String dbPass = "root";
    conn = DriverManager.getConnection(dbURL, dbUser, dbPass);

    // Prepare the SQL statement
    String sql = "SELECT * FROM out_details WHERE full_name = ? AND password= ? ";
    pstmt = conn.prepareStatement(sql);
    pstmt.setString(1, full_name);
    pstmt.setString(2, password);
  

    // Execute the query
    rs = pstmt.executeQuery();

    // Check if the emp_id, designation, and department match
    if (rs.next()) {
        // Successful login, set the session attribute and redirect to dashboard
        HttpSession session = request.getSession();
        session.setAttribute("full_name", full_name);
        session.setAttribute("password", password);
        response.sendRedirect("dashboard.jsp");
    } else {
        // Login failed, redirect to login page with an error message
    	 request.setAttribute("errorMessage", "Invalid credentials");
         request.getRequestDispatcher("out_login.jsp").forward(request, response);
    }
} catch (Exception e) {
    e.printStackTrace();
    request.setAttribute("errorMessage", "Invalid credentials");
    request.getRequestDispatcher("out_login.jsp").forward(request, response);
} finally {
    // Close the resources
    try {
        if (rs != null) rs.close();
        if (pstmt != null) pstmt.close();
        if (conn != null) conn.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
    }
}


